package com.marcaci.nbrigadistas.Brigada.empresarial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BrigadaEmpresarialApplicationTests {

	@Test
	void contextLoads() {
	}

}
